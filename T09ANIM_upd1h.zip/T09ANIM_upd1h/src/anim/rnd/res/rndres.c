#include "rndres.h"

VOID IK1_RndResInit( VOID )
{
}

VOID IK1_RndResClose( VOID )
{
}
